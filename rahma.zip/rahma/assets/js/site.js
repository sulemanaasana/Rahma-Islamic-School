(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  $('#year').textContent = new Date().getFullYear();

  /* ---------- Admission status ---------- */
  var admissionsOpen = null;

  function applyStatus(open) {
    admissionsOpen = open;
    var dot = $('#status-dot'), text = $('#status-text');
    dot.className = 'inline-block w-2.5 h-2.5 rounded-full pulse-dot ' + (open ? 'bg-green-400' : 'bg-red-400');
    text.textContent = open ? 'Admissions are OPEN' : 'Admissions are CLOSED';
    $('#closed-notice').classList.toggle('hidden', open);
    var fields = $('#apply-fields');
    fields.disabled = !open;
    $('#apply-submit').disabled = !open;
    $('#apply-submit').textContent = open ? 'Submit application' : 'Admissions closed';
  }

  function fetchStatus() {
    fetch('/api/admissions/status', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && typeof d.open === 'boolean') applyStatus(d.open); })
      .catch(function () {
        $('#status-dot').className = 'inline-block w-2.5 h-2.5 rounded-full bg-gray-400';
        $('#status-text').textContent = 'Admission status unavailable';
      });
  }
  fetchStatus();
  setInterval(fetchStatus, 20000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) fetchStatus(); });

  /* ---------- Mobile drawer ---------- */
  var drawer = $('#drawer'), overlay = $('#drawer-overlay'), menuBtn = $('#menu-btn');
  function openDrawer() {
    drawer.classList.remove('translate-x-full');
    overlay.classList.remove('hidden');
    drawer.setAttribute('aria-hidden', 'false');
    menuBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    $('#drawer-close').focus();
  }
  function closeDrawer(restore) {
    drawer.classList.add('translate-x-full');
    overlay.classList.add('hidden');
    drawer.setAttribute('aria-hidden', 'true');
    menuBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    if (restore) menuBtn.focus();
  }
  menuBtn.addEventListener('click', openDrawer);
  $('#drawer-close').addEventListener('click', function () { closeDrawer(true); });
  overlay.addEventListener('click', function () { closeDrawer(true); });
  $$('.drawer-link').forEach(function (a) { a.addEventListener('click', function () { closeDrawer(false); }); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && drawer.getAttribute('aria-hidden') === 'false') closeDrawer(true);
  });
  // Keep tab focus out of the hidden drawer
  drawer.addEventListener('keydown', function (e) {
    if (e.key !== 'Tab' || drawer.getAttribute('aria-hidden') === 'true') return;
    var f = $$('a,button', drawer);
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  window.matchMedia('(min-width:1024px)').addEventListener('change', function (m) { if (m.matches) closeDrawer(false); });

  /* ---------- Timetable ---------- */
  (function buildTimetable() {
    var rows = [
      { label: 'Regular weekend classes', cls: 'bg-wine', days: [0, 0, 0, 0, 0, 1, 1], txt: 'text-white' },
      { label: 'Vacation intensive', cls: 'bg-gold', days: [0, 0, 1, 0, 0, 1, 1], txt: 'text-wine-deep' }
    ];
    // Vacation runs Saturday to Wednesday: Sat, Sun, Mon, Tue, Wed
    rows[1].days = [1, 1, 1, 0, 0, 1, 1];
    var names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    var tb = $('#timetable');
    rows.forEach(function (r) {
      var tr = document.createElement('tr');
      var th = document.createElement('th');
      th.scope = 'row'; th.className = 'text-left px-4 py-4 font-semibold text-wine-dark';
      th.textContent = r.label; tr.appendChild(th);
      r.days.forEach(function (on, i) {
        var td = document.createElement('td'); td.className = 'p-1.5';
        var box = document.createElement('div');
        box.className = 'rounded-lg py-3 text-xs font-bold ' + (on ? r.cls + ' ' + r.txt : 'bg-gray-100 text-gray-400');
        box.textContent = on ? 'Class' : '—';
        box.setAttribute('aria-label', names[i] + ': ' + (on ? 'class' : 'no class'));
        td.appendChild(box); tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
  })();

  /* ---------- Gallery + lightbox ---------- */
  var scenes = [
    { t: 'Quran circle on a Saturday morning', bg: '#722F37', draw: function () {
      return '<circle cx="400" cy="300" r="170" fill="#4A1720"/>' +
        [0,1,2,3,4,5].map(function (i) { var a = i * Math.PI / 3; var x = 400 + 120 * Math.cos(a), y = 300 + 120 * Math.sin(a);
          return '<circle cx="' + x + '" cy="' + (y - 18) + '" r="22" fill="#F9E7A2"/><rect x="' + (x - 24) + '" y="' + (y + 6) + '" width="48" height="40" rx="14" fill="#F2C94C"/>'; }).join('') +
        '<rect x="365" y="270" width="70" height="50" rx="6" fill="#FFF9ED"/><path d="M400 270v50" stroke="#722F37" stroke-width="3"/>'; } },
    { t: 'Arabic calligraphy practice', bg: '#4A1720', draw: function () {
      return '<rect x="140" y="110" width="520" height="300" rx="14" fill="#FFF9ED"/>' +
        '<text x="400" y="290" text-anchor="middle" font-size="150" fill="#722F37" font-family="Amiri,serif">رحمة</text>' +
        '<path d="M190 340h420" stroke="#F2C94C" stroke-width="6" stroke-linecap="round"/>'; } },
    { t: 'The Junior class at lessons', bg: '#F2C94C', draw: function () {
      return '<rect x="120" y="120" width="560" height="140" rx="10" fill="#722F37"/><text x="400" y="215" text-anchor="middle" font-size="86" fill="#F9E7A2" font-family="Amiri,serif">أ ب ت ث</text>' +
        [0,1,2,3].map(function (i) { var x = 190 + i * 140; return '<circle cx="' + x + '" cy="340" r="28" fill="#4A1720"/><rect x="' + (x - 36) + '" y="372" width="72" height="56" rx="18" fill="#722F37"/>'; }).join(''); } },
    { t: 'Our school courtyard', bg: '#F9E7A2', draw: function () {
      return '<rect x="0" y="380" width="800" height="220" fill="#F2C94C"/><path d="M250 380V250a150 150 0 01300 0v130z" fill="#722F37"/><path d="M290 380V260a110 110 0 01220 0v120z" fill="#4A1720"/>' +
        '<circle cx="400" cy="130" r="38" fill="#722F37"/><circle cx="414" cy="122" r="32" fill="#F9E7A2"/><rect x="396" y="50" width="8" height="42" fill="#722F37"/>'; } },
    { t: 'Certificate and prize day', bg: '#351017', draw: function () {
      return '<circle cx="400" cy="260" r="110" fill="#F2C94C"/><circle cx="400" cy="260" r="82" fill="#722F37"/>' +
        '<path d="M400 205l15 31 34 5-25 24 6 34-30-16-30 16 6-34-25-24 34-5z" fill="#F9E7A2"/>' +
        '<path d="M345 350l-25 90 55-30 25 40 15-100z M455 350l25 90-55-30-25 40-15-100z" fill="#F2C94C" opacity=".85"/>'; } },
    { t: 'The reading corner library', bg: '#722F37', draw: function () {
      var cols = ['#F2C94C','#F9E7A2','#FFF9ED','#F2C94C','#F9E7A2','#FFF9ED','#F2C94C'];
      var s = '<rect x="110" y="140" width="580" height="330" rx="10" fill="#4A1720"/><rect x="130" y="300" width="540" height="10" fill="#351017"/><rect x="130" y="440" width="540" height="10" fill="#351017"/>';
      for (var i = 0; i < 14; i++) { var c = cols[i % cols.length]; s += '<rect x="' + (140 + i * 38) + '" y="' + (190 + (i % 3) * 10) + '" width="28" height="' + (110 - (i % 3) * 10) + '" fill="' + c + '"/>'; }
      for (var j = 0; j < 14; j++) { s += '<rect x="' + (140 + j * 38) + '" y="' + (330 + (j % 4) * 8) + '" width="28" height="' + (110 - (j % 4) * 8) + '" fill="' + cols[(j + 3) % cols.length] + '"/>'; }
      return s; } }
  ];
  function svgUrl(sc) {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600"><rect width="800" height="600" fill="' + sc.bg + '"/>' + sc.draw() + '</svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
  var gallery = scenes.map(function (s) { return { src: svgUrl(s), caption: s.t }; });
  /* To use real photos, replace the 'src' values with e.g. '/assets/gallery/photo1.jpg'. */

  var grid = $('#gallery-grid');
  gallery.forEach(function (g, i) {
    var li = document.createElement('li');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'group relative block w-full aspect-[4/3] overflow-hidden rounded-xl ring-1 ring-gold-soft focus-visible:ring-4';
    btn.setAttribute('aria-label', 'View full screen: ' + g.caption);
    btn.setAttribute('aria-haspopup', 'dialog');
    var img = document.createElement('img');
    img.src = g.src; img.alt = ''; img.loading = 'lazy';
    img.className = 'w-full h-full object-cover transition-transform duration-300 group-hover:scale-105';
    var cap = document.createElement('span');
    cap.className = 'absolute inset-x-0 bottom-0 p-2 sm:p-3 text-left text-xs sm:text-sm font-medium text-white bg-gradient-to-t from-black/70 to-transparent';
    cap.textContent = g.caption;
    btn.appendChild(img); btn.appendChild(cap); li.appendChild(btn); grid.appendChild(li);
    btn.addEventListener('click', function () { openLightbox(i, btn); });
  });

  var lb = $('#lightbox'), lbImg = $('#lb-img'), lbCap = $('#lb-caption');
  var lbIndex = 0, lbOpener = null;
  function showLb(i) {
    lbIndex = (i + gallery.length) % gallery.length;
    lbImg.src = gallery[lbIndex].src;
    lbImg.alt = gallery[lbIndex].caption;
    lbCap.textContent = gallery[lbIndex].caption + '  (' + (lbIndex + 1) + ' of ' + gallery.length + ')';
  }
  function openLightbox(i, opener) {
    lbOpener = opener; showLb(i);
    lb.classList.remove('hidden'); lb.classList.add('flex');
    lb.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    $('#lb-close').focus();
  }
  function closeLightbox() {
    lb.classList.add('hidden'); lb.classList.remove('flex');
    lb.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (lbOpener) lbOpener.focus();
  }
  $('#lb-close').addEventListener('click', closeLightbox);
  $('#lb-prev').addEventListener('click', function () { showLb(lbIndex - 1); });
  $('#lb-next').addEventListener('click', function () { showLb(lbIndex + 1); });
  lb.addEventListener('click', function (e) { if (e.target === lb) closeLightbox(); });
  document.addEventListener('keydown', function (e) {
    if (lb.getAttribute('aria-hidden') !== 'false') return;
    if (e.key === 'Escape') closeLightbox();
    else if (e.key === 'ArrowLeft') showLb(lbIndex - 1);
    else if (e.key === 'ArrowRight') showLb(lbIndex + 1);
    else if (e.key === 'Tab') {
      var f = $$('button', lb), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* ---------- Form helpers ---------- */
  function clearErrors(form) {
    $$('[data-err]', form).forEach(function (p) { p.textContent = ''; });
    $$('.field', form).forEach(function (f) { f.removeAttribute('aria-invalid'); });
  }
  function showErrors(form, fields) {
    var firstEl = null;
    Object.keys(fields || {}).forEach(function (k) {
      var p = $('[data-err="' + k + '"]', form);
      var input = form.elements[k];
      if (p) p.textContent = fields[k];
      if (input) { input.setAttribute('aria-invalid', 'true'); if (!firstEl) firstEl = input; }
    });
    if (firstEl) firstEl.focus();
  }
  function formData(form) {
    var o = {};
    $$('input,select,textarea', form).forEach(function (el) { if (el.name) o[el.name] = el.value; });
    return o;
  }
  function post(url, body) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Unexpected server response.' }; }).then(function (d) { d._status = r.status; return d; }); });
  }

  /* ---------- Admission form ---------- */
  var applyForm = $('#apply-form');
  var dobInput = $('#dob');
  (function () {
    var today = new Date(), iso = function (d) { return d.toISOString().slice(0, 10); };
    var min = new Date(today); min.setFullYear(min.getFullYear() - 25);
    var max = new Date(today); max.setFullYear(max.getFullYear() - 3);
    dobInput.min = iso(min); dobInput.max = iso(max);
  })();

  applyForm.addEventListener('submit', function (e) {
    e.preventDefault();
    if (admissionsOpen === false) return;
    clearErrors(applyForm);
    $('#apply-error').textContent = '';
    var data = formData(applyForm);
    var errs = {};
    if (data.child_name.trim().length < 2) errs.child_name = "Please enter the child's full name.";
    if (!data.dob) errs.dob = 'Please enter the date of birth.';
    if (!data.gender) errs.gender = 'Please select a gender.';
    if (!data.programme) errs.programme = 'Please select a programme.';
    if (data.parent_name.trim().length < 2) errs.parent_name = "Please enter the parent or guardian's name.";
    if (!/^[+\d][\d\s\-()]{6,19}$/.test(data.phone.trim())) errs.phone = 'Please enter a valid phone number.';
    if (Object.keys(errs).length) { showErrors(applyForm, errs); return; }

    var btn = $('#apply-submit');
    btn.disabled = true; btn.textContent = 'Submitting…';
    post('/api/admissions/apply', data).then(function (d) {
      if (d.ok) {
        applyForm.classList.add('hidden');
        $('#ref-number').textContent = d.reference;
        var s = $('#apply-success'); s.classList.remove('hidden'); s.focus();
        applyForm.reset();
        return;
      }
      if (d.closed) { applyStatus(false); return; }
      if (d.fields) showErrors(applyForm, d.fields);
      $('#apply-error').textContent = d.error || 'Something went wrong. Please try again.';
    }).catch(function () {
      $('#apply-error').textContent = 'Could not reach the server. Please check your connection and try again.';
    }).then(function () {
      btn.disabled = admissionsOpen === false;
      btn.textContent = admissionsOpen === false ? 'Admissions closed' : 'Submit application';
    });
  });
  $('#new-application').addEventListener('click', function () {
    $('#apply-success').classList.add('hidden');
    applyForm.classList.remove('hidden');
    $('#child_name').focus();
    fetchStatus();
  });

  /* ---------- Contact form ---------- */
  var cForm = $('#contact-form');
  cForm.addEventListener('submit', function (e) {
    e.preventDefault();
    clearErrors(cForm);
    var msg = $('#contact-msg'); msg.textContent = ''; msg.className = 'text-sm mt-3 min-h-[1.25rem]';
    var data = formData(cForm), errs = {};
    if (data.name.trim().length < 2) errs.name = 'Please enter your name.';
    if (!data.email.trim() && !data.phone.trim()) errs.email = 'Provide an email address or a phone number.';
    if (data.email.trim() && !/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(data.email.trim())) errs.email = 'Please enter a valid email address.';
    if (data.message.trim().length < 5) errs.message = 'Please write a short message.';
    if (Object.keys(errs).length) { showErrors(cForm, errs); return; }

    var btn = $('#contact-submit'); btn.disabled = true; btn.textContent = 'Sending…';
    post('/api/contact/send', data).then(function (d) {
      if (d.ok) {
        msg.textContent = 'Thank you. Your message has been sent and we will get back to you soon.';
        msg.className += ' text-green-700 font-semibold';
        cForm.reset();
      } else {
        if (d.fields) showErrors(cForm, d.fields);
        msg.textContent = d.error || 'Something went wrong. Please try again.';
        msg.className += ' text-red-700';
      }
    }).catch(function () {
      msg.textContent = 'Could not reach the server. Please try again.';
      msg.className += ' text-red-700';
    }).then(function () { btn.disabled = false; btn.textContent = 'Send message'; });
  });
})();
