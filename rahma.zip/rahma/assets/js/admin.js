(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var TOKEN_KEY = 'rahma_admin_token';
  var token = '';
  var state = { open: null, apps: [], msgs: [] };

  try { token = sessionStorage.getItem(TOKEN_KEY) || ''; } catch (e) { token = ''; }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function fmtDate(iso) {
    var d = new Date(iso);
    return isNaN(d) ? iso : d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
  }

  /* ---------- API ---------- */
  function api(method, url, body) {
    var opts = { method: method, headers: {}, cache: 'no-store' };
    if (token) opts.headers['Authorization'] = 'Bearer ' + token;
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    return fetch(url, opts).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: 'Unexpected server response.' }; })
        .then(function (d) { d._status = r.status; return d; });
    });
  }

  function showLogin(msg) {
    token = '';
    try { sessionStorage.removeItem(TOKEN_KEY); } catch (e) {}
    $('#dash-view').classList.add('hidden');
    $('#login-view').classList.remove('hidden');
    $('#login-error').textContent = msg || '';
    $('#password').value = '';
    $('#username').focus();
  }
  function showDash() {
    $('#login-view').classList.add('hidden');
    $('#dash-view').classList.remove('hidden');
    load();
  }

  /* ---------- Login ---------- */
  $('#toggle-pw').addEventListener('click', function () {
    var pw = $('#password'), show = pw.type === 'password';
    pw.type = show ? 'text' : 'password';
    this.textContent = show ? 'Hide' : 'Show';
    this.setAttribute('aria-pressed', String(show));
    this.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  });
  $('#login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var u = $('#username').value.trim(), p = $('#password').value;
    var err = $('#login-error'); err.textContent = '';
    if (!u || !p) { err.textContent = 'Enter your username and password.'; return; }
    var btn = $('#login-btn'); btn.disabled = true; btn.textContent = 'Signing in…';
    api('POST', '/api/admin/login', { username: u, password: p }).then(function (d) {
      if (d.ok && d.token) {
        token = d.token;
        try { sessionStorage.setItem(TOKEN_KEY, token); } catch (e) {}
        showDash();
      } else {
        err.textContent = d.error || 'Sign-in failed.';
      }
    }).catch(function () { err.textContent = 'Could not reach the server.'; })
      .then(function () { btn.disabled = false; btn.textContent = 'Sign in'; $('#password').value = ''; });
  });
  $('#logout-btn').addEventListener('click', function () {
    var done = function () { showLogin(''); };
    api('POST', '/api/admin/logout', {}).then(done, done);
  });

  /* ---------- Data ---------- */
  function load() {
    $('#dash-error').textContent = '';
    return api('GET', '/api/admin/applications').then(function (d) {
      if (d._status === 401) { showLogin('Your session has expired. Please sign in again.'); return; }
      if (!d.ok) { $('#dash-error').textContent = d.error || 'Failed to load data.'; return; }
      state.open = d.open; state.apps = d.applications || []; state.msgs = d.messages || [];
      render();
    }).catch(function () { $('#dash-error').textContent = 'Could not reach the server.'; });
  }

  function renderStatus() {
    var open = state.open === true;
    var sw = $('#toggle-switch');
    sw.disabled = state.open === null;
    sw.setAttribute('aria-checked', String(open));
    $('#switch-state').textContent = state.open === null ? 'Loading…' : (open ? 'OPEN' : 'CLOSED');
    $('#switch-hint').textContent = open ? 'The public application form is accepting submissions.' : 'The public application form is disabled.';
    var tb = $('#toggle-btn');
    tb.disabled = state.open === null;
    tb.textContent = open ? 'Close admissions' : 'Open admissions';
    var ov = $('#overview-status');
    ov.textContent = state.open === null ? '–' : (open ? 'OPEN' : 'CLOSED');
    ov.className = 'font-display text-4xl font-bold mt-1 ' + (open ? 'text-green-700' : 'text-red-700');
  }

  function render() {
    $('#count-apps').textContent = state.apps.length;
    $('#count-msgs').textContent = state.msgs.length;
    renderStatus();
    renderApps();
    renderMsgs();
  }

  function renderApps() {
    var q = $('#app-search').value.trim().toLowerCase();
    var body = $('#apps-body'); body.textContent = '';
    var rows = state.apps.filter(function (a) {
      if (!q) return true;
      return [a.reference, a.child_name, a.parent_name, a.phone, a.programme_label].join(' ').toLowerCase().indexOf(q) !== -1;
    });
    $('#apps-empty').classList.toggle('hidden', rows.length > 0);
    $('#apps-empty').textContent = state.apps.length ? 'No applications match your search.' : 'No applications yet.';
    rows.forEach(function (a) {
      var tr = el('tr', 'hover:bg-cream');
      tr.appendChild(el('td', 'px-4 py-3 font-mono font-semibold text-wine whitespace-nowrap', a.reference));
      tr.appendChild(el('td', 'px-4 py-3 font-medium', a.child_name));
      tr.appendChild(el('td', 'px-4 py-3', a.programme_label || a.programme));
      tr.appendChild(el('td', 'px-4 py-3', a.parent_name));
      var tdp = el('td', 'px-4 py-3 whitespace-nowrap');
      var link = el('a', 'text-wine underline', a.phone);
      link.href = 'tel:' + String(a.phone).replace(/[^\d+]/g, '');
      tdp.appendChild(link); tr.appendChild(tdp);
      tr.appendChild(el('td', 'px-4 py-3 whitespace-nowrap text-ink/70', fmtDate(a.submitted_at)));
      var tdb = el('td', 'px-4 py-3 text-right');
      var b = el('button', 'text-wine font-semibold text-xs px-3 py-1.5 rounded-full border border-wine hover:bg-wine hover:text-white', 'Details');
      b.type = 'button';
      b.setAttribute('aria-label', 'View details for ' + a.child_name);
      b.addEventListener('click', function () { openDetail(a); });
      tdb.appendChild(b); tr.appendChild(tdb);
      body.appendChild(tr);
    });
  }

  function renderMsgs() {
    var list = $('#msgs-list'); list.textContent = '';
    $('#msgs-empty').classList.toggle('hidden', state.msgs.length > 0);
    state.msgs.forEach(function (m) {
      var card = el('article', 'bg-white rounded-2xl border border-gold-soft p-5');
      var head = el('div', 'flex justify-between gap-3 items-start');
      head.appendChild(el('h3', 'font-bold text-wine-dark', m.name));
      head.appendChild(el('time', 'text-xs text-ink/60 whitespace-nowrap', fmtDate(m.received_at)));
      card.appendChild(head);
      var contact = [m.email, m.phone].filter(Boolean).join(' · ');
      if (contact) card.appendChild(el('p', 'text-xs text-wine mt-1', contact));
      card.appendChild(el('p', 'text-sm mt-3 whitespace-pre-wrap break-words', m.message));
      list.appendChild(card);
    });
  }

  $('#app-search').addEventListener('input', renderApps);
  $('#refresh-btn').addEventListener('click', load);

  /* ---------- Toggle ---------- */
  function toggle() {
    var btn = $('#toggle-btn'), sw = $('#toggle-switch');
    btn.disabled = true; sw.disabled = true;
    var target = !state.open;
    api('POST', '/api/admin/toggle-status', { open: target }).then(function (d) {
      if (d._status === 401) { showLogin('Your session has expired. Please sign in again.'); return; }
      if (d.ok) { state.open = d.open; $('#dash-error').textContent = ''; }
      else { $('#dash-error').textContent = d.error || 'Could not change status.'; }
    }).catch(function () { $('#dash-error').textContent = 'Could not reach the server.'; })
      .then(function () { renderStatus(); });
  }
  $('#toggle-btn').addEventListener('click', toggle);
  $('#toggle-switch').addEventListener('click', toggle);

  /* ---------- Details dialog ---------- */
  var dlg = $('#detail-dialog');
  function openDetail(a) {
    $('#detail-title').textContent = a.reference;
    var dl = $('#detail-body'); dl.textContent = '';
    [
      ['Student', a.child_name], ['Date of birth', a.dob], ['Gender', a.gender],
      ['Programme', a.programme_label], ['Parent / guardian', a.parent_name],
      ['Phone', a.phone], ['Notes', a.notes || '—'], ['Submitted', fmtDate(a.submitted_at)]
    ].forEach(function (r) {
      var row = el('div', 'grid grid-cols-3 gap-3 border-b border-gold-soft pb-2');
      row.appendChild(el('dt', 'text-ink/60', r[0]));
      row.appendChild(el('dd', 'col-span-2 font-medium whitespace-pre-wrap break-words', r[1]));
      dl.appendChild(row);
    });
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
  }
  $('#detail-close').addEventListener('click', function () { dlg.close(); });
  dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });

  /* ---------- CSV export ---------- */
  function csvCell(v) {
    var s = String(v == null ? '' : v);
    // Neutralise spreadsheet formula injection
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  }
  $('#export-csv').addEventListener('click', function () {
    var head = ['Reference', 'Student', 'Date of birth', 'Gender', 'Programme', 'Parent', 'Phone', 'Notes', 'Submitted'];
    var lines = [head.map(csvCell).join(',')];
    state.apps.forEach(function (a) {
      lines.push([a.reference, a.child_name, a.dob, a.gender, a.programme_label, a.parent_name, a.phone, a.notes, a.submitted_at].map(csvCell).join(','));
    });
    var blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'rahma-applications-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
  });

  /* ---------- Init ---------- */
  if (token) showDash(); else showLogin('');
  setInterval(function () { if (token && !document.hidden) load(); }, 30000);
})();
