/* Rahma - motion layer (progressive enhancement: the page is fully usable without it). */
(function () {
  'use strict';
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var hasIO = 'IntersectionObserver' in window;

  /* ---------- hero: pause the photo slideshow while it is off-screen ---------- */
  var hero = $('#top'), bg = $('.hero-bg');
  if (hero && bg && !reduce && hasIO) {
    new IntersectionObserver(function (entries) {
      bg.classList.toggle('is-paused', !entries[0].isIntersecting);
    }).observe(hero);
  }

  if (reduce || !hasIO) return;   // everything below is scroll-reveal only

  /* ---------- scroll reveal for cards, panels and headings ---------- */
  var CARDS = '#about article, #programmes article, #schedule article, #faculty article, #contact article';
  var PANELS = '#apply-form, #contact-form, #schedule .mt-10.bg-white';
  // (#apply-success is excluded: it starts hidden and is shown by site.js after a submission)
  var HEADS = 'section:not(#top) .text-center:not(#apply-success), #about .max-w-3xl';
  var TILES = '#gallery-grid li';
  var FOOT = 'footer .grid > *';

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      var el = e.target;
      io.unobserve(el);
      el.classList.add('in');
      // After the entrance finishes, drop the entrance delay so hover is instant.
      var settle = (parseFloat(el.style.getPropertyValue('--d')) || 0) * 1000 + 900;
      setTimeout(function () { el.classList.add('done'); }, settle);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });

  function prepare(el, extra) {
    if (!el || el.classList.contains('reveal')) return;
    el.classList.add('reveal');
    if (extra) extra.split(' ').forEach(function (c) { el.classList.add(c); });
    io.observe(el);
  }

  // stagger siblings within the same parent
  function stagger(list, step, cap) {
    var counts = new Map();
    list.forEach(function (el) {
      var n = counts.get(el.parentNode) || 0;
      counts.set(el.parentNode, n + 1);
      el.style.setProperty('--d', (Math.min(n, cap) * step).toFixed(2) + 's');
    });
  }

  var cards = $$(CARDS);
  stagger(cards, 0.12, 5);
  cards.forEach(function (card) {
    card.classList.add('card-fx');
    var icon = card.querySelector(':scope > [aria-hidden="true"]');
    if (icon) icon.classList.add('fx-icon');
    prepare(card);
  });

  var tiles = $$(TILES);
  stagger(tiles, 0.08, 6);
  tiles.forEach(function (t) { prepare(t); });

  $$(PANELS).forEach(function (p) { prepare(p); });
  $$(HEADS).forEach(function (h) { prepare(h); });

  var foot = $$(FOOT);
  stagger(foot, 0.1, 3);
  foot.forEach(function (f) { prepare(f); });

  // contact form slides in from the right, the contact cards from the left
  var cf = $('#contact-form'); if (cf) cf.classList.add('from-right');
  $$('#contact .lg\\:col-span-2 article').forEach(function (a) { a.classList.add('from-left'); });

  /* ---------- timetable cells ---------- */
  var tt = $('#timetable');
  if (tt) {
    $$('td > div', tt).forEach(function (cell) {
      cell.classList.add('cell');
      var col = cell.parentNode.cellIndex;                    // 1..7
      var row = cell.parentNode.parentNode.rowIndex;
      cell.style.setProperty('--d', (0.15 + col * 0.07 + row * 0.1).toFixed(2) + 's');
    });
    var ttIO = new IntersectionObserver(function (entries) {
      if (!entries[0].isIntersecting) return;
      ttIO.disconnect();
      tt.classList.add('tt-in');
    }, { threshold: 0.3 });
    ttIO.observe(tt);
  }
})();
