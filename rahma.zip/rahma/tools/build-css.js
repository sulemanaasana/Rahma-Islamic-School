/*
 * Builds assets/css/app.css.
 * Runs the Tailwind 3.4 browser build in headless Chromium against every class
 * name found in the HTML and JS, then writes a static, minified stylesheet.
 *
 * Usage:  NODE_PATH=$(npm root -g) TAILWIND_RUNTIME=/path/to/tailwindcss.js node tools/build-css.js
 * Re-run whenever you add or change Tailwind classes in index.html, admin.html or assets/js/*.js.
 */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const root = path.resolve(__dirname, '..');
const runtime = process.env.TAILWIND_RUNTIME ||
  '/opt/npm-tools/node_modules/@zenuml/core/dist/vendor/tailwindcss/tailwindcss.js';
const config = fs.readFileSync(path.join(__dirname, 'tailwind.config.json'), 'utf8');
const base = fs.readFileSync(path.join(__dirname, 'base.css'), 'utf8');

function candidates() {
  const set = new Set();
  const add = (s) => s.split(/\s+/).forEach((t) => { if (t && t.length < 80) set.add(t); });
  for (const f of ['index.html', 'admin.html']) {
    const html = fs.readFileSync(path.join(root, f), 'utf8');
    for (const m of html.matchAll(/class="([^"]*)"/g)) add(m[1]);
  }
  for (const f of fs.readdirSync(path.join(root, 'assets/js'))) {
    const js = fs.readFileSync(path.join(root, 'assets/js', f), 'utf8');
    for (const m of js.matchAll(/'([^'\n]*)'|"([^"\n]*)"|`([^`]*)`/g)) add(m[1] || m[2] || m[3] || '');
  }
  return [...set];
}

function minify(css) {
  return css
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\s+/g, ' ')
    .replace(/\s*([{};,])\s*/g, '$1')
    .replace(/;}/g, '}')
    .trim();
}

(async () => {
  const exe = process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium';
  const browser = await chromium.launch({ executablePath: fs.existsSync(exe) ? exe : undefined });
  const page = await browser.newPage();
  const html = `<!doctype html><html><head><meta charset="utf-8"></head><body><div id="probe" hidden></div></body></html>`;
  await page.setContent(html);
  await page.addScriptTag({ content: fs.readFileSync(runtime, 'utf8') });
  await page.evaluate((cfg) => { window.tailwind.config = JSON.parse(cfg); }, config);
  const list = candidates();
  await page.evaluate((c) => { document.getElementById('probe').className = c.join(' '); }, list);
  await page.waitForTimeout(2500);
  const generated = await page.evaluate(() =>
    [...document.querySelectorAll('style')].map((s) => s.textContent).join('\n'));
  await browser.close();
  if (generated.length < 5000) throw new Error('Tailwind output looks empty (' + generated.length + ' bytes)');
  const out = minify(base.split('/* Site components')[0]) + minify(generated) +
    minify('/* Site components' + base.split('/* Site components')[1]);
  // Site components must come BEFORE tailwind utilities; reorder explicitly:
  const fonts = minify(base.split('/* Site components')[0]);
  const comps = minify('/*x*/' + base.split('/* Site components')[1]);
  const final = fonts + comps + minify(generated);
  fs.mkdirSync(path.join(root, 'assets/css'), { recursive: true });
  fs.writeFileSync(path.join(root, 'assets/css/app.css'), final);
  console.log('candidates:', list.length, ' app.css:', final.length, 'bytes');
})().catch((e) => { console.error(e); process.exit(1); });
