#!/usr/bin/env bash
# Installs (or updates) the Rahma website on an Ubuntu/Debian server with HTTPS.
#
#   sudo ./deploy/install.sh school.example.com you@example.com
#
# Prerequisites: the domain's DNS A/AAAA record already points to this server and
# ports 80 and 443 are open. Safe to re-run to deploy updates: your data, admin
# password and certificate are kept.
set -euo pipefail

DOMAIN="${1:-}"
EMAIL="${2:-}"
usage() { echo "Usage: sudo $0 <domain> <email-for-certificate-notices>"; exit 1; }
[[ $EUID -eq 0 ]] || { echo "Please run as root (sudo)."; exit 1; }
[[ "$DOMAIN" =~ ^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || usage
[[ "$EMAIL" == *@*.* ]] || usage

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP=/opt/rahma
ENVDIR=/etc/rahma
ENVFILE="$ENVDIR/rahma.env"

echo "==> Installing packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nginx certbot python3 openssl curl

echo "==> Installing application to $APP"
id rahma >/dev/null 2>&1 || useradd --system --home-dir /var/lib/rahma --shell /usr/sbin/nologin rahma
install -d -m 755 "$APP"
rm -rf "$APP/assets"
cp -r "$SRC/assets" "$APP/assets"
install -m 644 "$SRC/server.py" "$SRC/index.html" "$SRC/admin.html" "$SRC/robots.txt" "$APP/"
chown -R root:root "$APP"
chmod -R go-w "$APP"

echo "==> Configuring"
install -d -m 750 -o root -g rahma "$ENVDIR"
if [[ ! -f "$ENVFILE" ]]; then
  PASS="$(openssl rand -base64 24 | tr -d '/+=' | cut -c1-20)"
  HASH="$(RAHMA_PW="$PASS" python3 - <<'PY'
import os, sys
sys.path.insert(0, "/opt/rahma")
import server
print(server.hash_password(os.environ["RAHMA_PW"]))
PY
)"
  umask 077
  cat > "$ENVFILE" <<ENV
RAHMA_ENV=production
HOST=127.0.0.1
PORT=8000
RAHMA_DATA_DIR=/var/lib/rahma
RAHMA_ADMIN_USER=admin
RAHMA_ADMIN_PASS_HASH=$HASH
ENV
  chown root:rahma "$ENVFILE"; chmod 640 "$ENVFILE"
  printf 'Admin login for https://%s/admin.html\nUsername: admin\nPassword: %s\n' "$DOMAIN" "$PASS" > /root/rahma-admin-credentials.txt
  chmod 600 /root/rahma-admin-credentials.txt
  NEW_PASS="$PASS"
fi

install -m 644 "$SRC/deploy/rahma.service" /etc/systemd/system/rahma.service
systemctl daemon-reload
systemctl enable rahma >/dev/null
systemctl restart rahma

echo "==> Configuring nginx and HTTPS"
install -d /etc/nginx/snippets /var/www/certbot
install -m 644 "$SRC/deploy/rahma-proxy.conf" /etc/nginx/snippets/rahma-proxy.conf
rm -f /etc/nginx/sites-enabled/default
if [[ ! -d "/etc/letsencrypt/live/$DOMAIN" ]]; then
  cat > /etc/nginx/sites-available/rahma <<NGX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    location /.well-known/acme-challenge/ { root /var/www/certbot; }
    location / { return 200 'Setting up...'; }
}
NGX
  ln -sf /etc/nginx/sites-available/rahma /etc/nginx/sites-enabled/rahma
  nginx -t && systemctl reload nginx
  certbot certonly --webroot -w /var/www/certbot -d "$DOMAIN" -m "$EMAIL" --agree-tos --no-eff-email --non-interactive
fi
install -d /etc/letsencrypt/renewal-hooks/deploy
printf '#!/bin/sh\nsystemctl reload nginx\n' > /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh
chmod +x /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh
sed "s/__DOMAIN__/$DOMAIN/g" "$SRC/deploy/nginx-rahma.conf" > /etc/nginx/sites-available/rahma
ln -sf /etc/nginx/sites-available/rahma /etc/nginx/sites-enabled/rahma
nginx -t
systemctl enable nginx >/dev/null
systemctl reload nginx

echo "==> Checking"
sleep 2
curl -fsS --max-time 10 http://127.0.0.1:8000/healthz >/dev/null && echo "App is running."
curl -fsS --max-time 15 "https://$DOMAIN/healthz" >/dev/null && echo "HTTPS is working: https://$DOMAIN"

echo
echo "Done. Site:  https://$DOMAIN"
echo "      Admin: https://$DOMAIN/admin.html"
if [[ -n "${NEW_PASS:-}" ]]; then
  echo
  echo "Admin username: admin"
  echo "Admin password: $NEW_PASS      (also saved to /root/rahma-admin-credentials.txt - delete it once stored safely)"
fi
echo "Data and daily backups: /var/lib/rahma"
