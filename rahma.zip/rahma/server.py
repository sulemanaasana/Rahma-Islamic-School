#!/usr/bin/env python3
"""
Rahma Islamic School & Arabic Study Center - web server (production build).

Serves the static site and a small JSON API using only the Python standard library.
Designed to run on 127.0.0.1 behind a reverse proxy (nginx/Caddy) that terminates HTTPS.

Usage
    python3 server.py                    start the server
    python3 server.py --check            validate configuration and exit
    python3 server.py --hash-password    print a password hash for RAHMA_ADMIN_PASS_HASH

Configuration (environment variables, see deploy/rahma.env.example)
    RAHMA_ENV               production (default) | development
    HOST / PORT             bind address (default 127.0.0.1:8000)
    RAHMA_ADMIN_USER        admin username (default: admin)
    RAHMA_ADMIN_PASS_HASH   admin password hash from --hash-password (preferred)
    RAHMA_ADMIN_PASS        admin password in plain text (min. 12 chars; hashed at start-up)
    RAHMA_DATA_DIR          where data is stored (default: ./data)
    RAHMA_TRUSTED_PROXIES   proxies allowed to set X-Forwarded-* (default: 127.0.0.1,::1)
    RAHMA_ALLOWED_ORIGINS   extra browser origins allowed to POST (comma separated)

In production the server refuses to start without a strong admin password.
"""
import argparse
import getpass
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import shutil
import signal
import sys
import threading
import time
import traceback
from datetime import date, datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

BASE_DIR = Path(__file__).resolve().parent

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
PRODUCTION = os.environ.get("RAHMA_ENV", "production").strip().lower() != "development"
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8000"))
DATA_DIR = Path(os.environ.get("RAHMA_DATA_DIR", str(BASE_DIR / "data"))).resolve()

DEV_PASSWORD = "rahma2026dodowa"          # accepted ONLY when RAHMA_ENV=development
BANNED_PASSWORDS = {DEV_PASSWORD, "password", "admin", "admin123", "changeme"}
MIN_PASSWORD_LEN = 12
PBKDF2_ITERATIONS = 600_000

MAX_BODY = 32 * 1024
SESSION_TTL = 60 * 60 * 8
LOGIN_WINDOW = 15 * 60
LOGIN_MAX_FAILS_PER_IP = 5
LOGIN_MAX_FAILS_GLOBAL = 40
SUBMIT_WINDOW = 10 * 60
SUBMIT_MAX = 8
BACKUPS_TO_KEEP = 30
SOCKET_TIMEOUT = 15

PAGES = {
    "/": "index.html",
    "/index.html": "index.html",
    "/admin": "admin.html",
    "/admin.html": "admin.html",
    "/robots.txt": "robots.txt",
}
ASSET_TYPES = {
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".ico": "image/x-icon",
}
PAGE_TYPES = {".html": "text/html; charset=utf-8", ".txt": "text/plain; charset=utf-8"}

PROGRAMMES = {
    "junior": "Junior Quran & Arabic Class",
    "advanced": "Advanced Arabic Studies",
    "vacation": "Vacation Intensive Program",
}
GENDERS = {"Male", "Female"}

CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; "
    "form-action 'self'; frame-ancestors 'none'"
)


def log(msg):
    print("%s %s" % (datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), msg), flush=True)


# --------------------------------------------------------------------------
# Passwords
# --------------------------------------------------------------------------
def hash_password(password, salt=None, iterations=PBKDF2_ITERATIONS):
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256$%d$%s$%s" % (iterations, salt.hex(), dk.hex())


def verify_password(password, stored):
    try:
        algo, iters, salt, digest = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(dk.hex(), digest)
    except (ValueError, TypeError):
        return False


def load_credentials():
    """Returns (username, password_hash, problems)."""
    user = os.environ.get("RAHMA_ADMIN_USER", "admin").strip() or "admin"
    stored = os.environ.get("RAHMA_ADMIN_PASS_HASH", "").strip()
    plain = os.environ.get("RAHMA_ADMIN_PASS", "")
    problems = []
    if stored:
        if not re.fullmatch(r"pbkdf2_sha256\$\d+\$[0-9a-f]+\$[0-9a-f]+", stored):
            problems.append("RAHMA_ADMIN_PASS_HASH is not valid. Generate one with: python3 server.py --hash-password")
    elif plain:
        if PRODUCTION and (len(plain) < MIN_PASSWORD_LEN or plain.lower() in BANNED_PASSWORDS):
            problems.append("RAHMA_ADMIN_PASS must be at least %d characters and not a common/default password." % MIN_PASSWORD_LEN)
        stored = hash_password(plain)
    elif PRODUCTION:
        problems.append("Set RAHMA_ADMIN_PASS_HASH (preferred) or RAHMA_ADMIN_PASS.")
    else:
        stored = hash_password(DEV_PASSWORD)
    if PRODUCTION and len(user) < 3:
        problems.append("RAHMA_ADMIN_USER must be at least 3 characters.")
    return user, stored, problems


# --------------------------------------------------------------------------
# Network helpers
# --------------------------------------------------------------------------
def _networks(raw):
    nets = []
    for part in (raw or "").split(","):
        part = part.strip()
        if part:
            nets.append(ipaddress.ip_network(part, strict=False))
    return nets


TRUSTED_PROXIES = _networks(os.environ.get("RAHMA_TRUSTED_PROXIES", "127.0.0.1,::1"))
EXTRA_ORIGINS = {o.strip().lower() for o in os.environ.get("RAHMA_ALLOWED_ORIGINS", "").split(",") if o.strip()}


def _ip(text):
    try:
        ip = ipaddress.ip_address(text.strip())
    except ValueError:
        return None
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip


def is_trusted_proxy(text):
    ip = _ip(text)
    return bool(ip) and any(ip in net for net in TRUSTED_PROXIES)


# --------------------------------------------------------------------------
# Persistent data
# --------------------------------------------------------------------------
def _write_json_atomic(path, payload):
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


class Store:
    """In-memory copy of the data, written through to disk on every change."""

    def __init__(self, data_dir):
        self.dir = data_dir
        self.file = data_dir / "store.json"
        self.backup_dir = data_dir / "backups"
        self.lock = threading.RLock()
        self.dir.mkdir(parents=True, exist_ok=True)
        os.chmod(self.dir, 0o700)
        self.backup_dir.mkdir(exist_ok=True)
        self.data = self._load()

    @staticmethod
    def _blank():
        return {"admissions_open": True, "applications": [], "messages": []}

    def _valid(self, data):
        return (isinstance(data, dict) and isinstance(data.get("applications"), list)
                and isinstance(data.get("messages"), list))

    def _load(self):
        if not self.file.exists():
            return self._blank()
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            if self._valid(data):
                base = self._blank()
                base.update(data)
                return base
        except (OSError, ValueError):
            pass
        # Never overwrite a damaged file: set it aside, then restore the newest good backup.
        aside = self.file.with_name("store.corrupt-%s.json" % datetime.now().strftime("%Y%m%d-%H%M%S"))
        try:
            os.replace(self.file, aside)
            log("WARNING: store.json was unreadable; moved to %s" % aside.name)
        except OSError:
            pass
        for backup in sorted(self.backup_dir.glob("store-*.json"), reverse=True):
            try:
                data = json.loads(backup.read_text(encoding="utf-8"))
                if self._valid(data):
                    log("Restored data from backup %s" % backup.name)
                    base = self._blank()
                    base.update(data)
                    return base
            except (OSError, ValueError):
                continue
        return self._blank()

    def save(self):
        with self.lock:
            _write_json_atomic(self.file, self.data)
            self._daily_backup()

    def _daily_backup(self):
        target = self.backup_dir / ("store-%s.json" % date.today().strftime("%Y%m%d"))
        try:
            shutil.copyfile(self.file, target)  # refreshed on every save: the day's latest state
            os.chmod(target, 0o600)
            for old in sorted(self.backup_dir.glob("store-*.json"), reverse=True)[BACKUPS_TO_KEEP:]:
                old.unlink()
        except OSError as exc:
            log("WARNING: backup failed: %s" % exc)


class Sessions:
    """Admin sessions. Only SHA-256 hashes of tokens are stored, so they survive restarts safely."""

    def __init__(self, data_dir):
        self.file = data_dir / "sessions.json"
        self.lock = threading.RLock()
        self.items = {}
        try:
            raw = json.loads(self.file.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                self.items = {k: float(v) for k, v in raw.items()}
        except (OSError, ValueError):
            pass
        self._prune(save=True)

    @staticmethod
    def _key(token):
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def _prune(self, save=False):
        now = time.time()
        dead = [k for k, exp in self.items.items() if exp < now]
        for k in dead:
            self.items.pop(k, None)
        if dead or save:
            self._persist()

    def _persist(self):
        try:
            _write_json_atomic(self.file, self.items)
        except OSError as exc:
            log("WARNING: could not save sessions: %s" % exc)

    def create(self):
        token = secrets.token_urlsafe(32)
        with self.lock:
            self._prune()
            self.items[self._key(token)] = time.time() + SESSION_TTL
            self._persist()
        return token

    def valid(self, token):
        if not token:
            return False
        with self.lock:
            exp = self.items.get(self._key(token))
            if exp is None:
                return False
            if exp < time.time():
                self.items.pop(self._key(token), None)
                self._persist()
                return False
            return True

    def revoke(self, token):
        with self.lock:
            if self.items.pop(self._key(token), None) is not None:
                self._persist()


class RateLimiter:
    def __init__(self):
        self.lock = threading.Lock()
        self.hits = {}

    def count(self, key, window):
        now = time.time()
        with self.lock:
            fresh = [t for t in self.hits.get(key, []) if now - t < window]
            self.hits[key] = fresh
            return len(fresh)

    def add(self, key, window):
        now = time.time()
        with self.lock:
            fresh = [t for t in self.hits.get(key, []) if now - t < window]
            fresh.append(now)
            self.hits[key] = fresh
            if len(self.hits) > 20000:  # keep memory bounded
                for k in [k for k, v in self.hits.items() if not v or now - v[-1] > window]:
                    self.hits.pop(k, None)

    def clear(self, key):
        with self.lock:
            self.hits.pop(key, None)

    def check_and_add(self, key, window, limit):
        """True if the caller is over the limit; otherwise records the hit."""
        if self.count(key, window) >= limit:
            return True
        self.add(key, window)
        return False


# Initialised in main()
STORE = None
SESSIONS = None
ADMIN_USER = ""
ADMIN_HASH = ""
DUMMY_HASH = hash_password("dummy-value-for-constant-time", salt=b"\x00" * 16)
LIMITER = RateLimiter()


# --------------------------------------------------------------------------
# Validation helpers
# --------------------------------------------------------------------------
def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def clean(value, max_len):
    if not isinstance(value, str):
        return ""
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", value).strip()
    return value[:max_len]


def valid_phone(phone):
    digits = re.sub(r"\D", "", phone)
    return bool(re.fullmatch(r"[+\d][\d\s\-()]{6,19}", phone)) and 9 <= len(digits) <= 15


def valid_email(email):
    return bool(re.fullmatch(r"[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,}", email))


def parse_dob(text):
    try:
        return datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# HTTP handler
# --------------------------------------------------------------------------
_static_cache = {}


class Handler(BaseHTTPRequestHandler):
    server_version = "Rahma"
    sys_version = ""
    protocol_version = "HTTP/1.0"      # one request per connection: simple and safe behind a proxy
    timeout = SOCKET_TIMEOUT           # drops stalled/slow-loris connections

    # -- logging / client info ----------------------------------------------
    def log_message(self, fmt, *args):
        log("%s %s" % (self.client_ip(), fmt % args))

    def log_error(self, fmt, *args):
        log("%s ERROR %s" % (self.client_ip(), fmt % args))

    def client_ip(self):
        peer = self.client_address[0]
        if not is_trusted_proxy(peer):
            return peer
        hops = [h for h in (self.headers.get("X-Forwarded-For", "") if self.headers else "").split(",") if h.strip()]
        valid = [h.strip() for h in hops if _ip(h)]
        for hop in reversed(valid):
            if not is_trusted_proxy(hop):
                return str(_ip(hop))
        return str(_ip(valid[0])) if valid else peer

    def via_https(self):
        return is_trusted_proxy(self.client_address[0]) and \
            self.headers.get("X-Forwarded-Proto", "").lower() == "https"

    # -- responses ----------------------------------------------------------
    def common_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Content-Security-Policy", CSP)
        if self.via_https():
            self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

    def send_bytes(self, status, body, ctype, extra=None, head=False):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.common_headers()
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_bytes(status, body, "application/json; charset=utf-8", {"Cache-Control": "no-store"})

    def error_json(self, status, message, **extra):
        self.send_json({"ok": False, "error": message, **extra}, status)

    # -- request parsing ----------------------------------------------------
    def read_json(self):
        if self.headers.get("Transfer-Encoding"):
            self.error_json(411, "Content-Length is required.")
            return None
        if (self.headers.get("Content-Type") or "").split(";")[0].strip().lower() != "application/json":
            self.error_json(415, "Content-Type must be application/json.")
            return None
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            self.error_json(400, "Request body is empty.")
            return None
        if length > MAX_BODY:
            self.error_json(413, "Request body too large.")
            return None
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            self.error_json(400, "Invalid JSON.")
            return None
        if not isinstance(data, dict):
            self.error_json(400, "JSON object expected.")
            return None
        return data

    def origin_ok(self):
        """Reject cross-site browser POSTs. Requests without an Origin header (curl, same-origin
        fetches from older browsers) pass; admin routes are protected by bearer token anyway."""
        origin = self.headers.get("Origin")
        if not origin:
            return True
        origin = origin.strip().lower()
        if origin in EXTRA_ORIGINS:
            return True
        host = self.headers.get("X-Forwarded-Host") if is_trusted_proxy(self.client_address[0]) else None
        host = (host or self.headers.get("Host") or "").strip().lower()
        return bool(host) and urlparse(origin).netloc == host

    def bearer(self):
        auth = self.headers.get("Authorization", "")
        return auth[7:].strip() if auth.startswith("Bearer ") else ""

    def require_admin(self):
        if SESSIONS.valid(self.bearer()):
            return True
        self.error_json(401, "Unauthorized. Please sign in again.")
        return False

    # -- routing ------------------------------------------------------------
    def _dispatch(self, fn):
        try:
            fn()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception:
            log("ERROR unhandled exception on %s %s\n%s" % (self.command, self.path, traceback.format_exc()))
            try:
                self.error_json(500, "Internal server error.")
            except Exception:
                pass

    def do_GET(self):
        self._dispatch(self._get)

    def do_HEAD(self):
        self._dispatch(lambda: self._get(head=True))

    def do_POST(self):
        self._dispatch(self._post)

    def _method_not_allowed(self):
        self._dispatch(lambda: self.error_json(405, "Method not allowed."))

    do_PUT = do_DELETE = do_PATCH = do_OPTIONS = _method_not_allowed

    def _get(self, head=False):
        path = urlparse(self.path).path
        if path == "/healthz":
            return self.send_json({"ok": True})
        if path == "/api/admissions/status":
            return self.api_status()
        if path == "/api/admin/applications":
            return self.api_admin_applications()
        if path.startswith("/api/"):
            return self.error_json(404, "Not found.")
        return self.serve_static(path, head)

    def _post(self):
        path = urlparse(self.path).path
        routes = {
            "/api/admissions/apply": self.api_apply,
            "/api/contact/send": self.api_contact,
            "/api/admin/login": self.api_login,
            "/api/admin/logout": self.api_logout,
            "/api/admin/toggle-status": self.api_toggle,
        }
        fn = routes.get(path)
        if not fn:
            return self.error_json(404, "Not found.")
        if not self.origin_ok():
            return self.error_json(403, "Cross-site request blocked.")
        return fn()

    # -- static files -------------------------------------------------------
    def resolve_static(self, path):
        if path == "/favicon.ico":
            return "redirect", "/assets/favicon.svg"
        if path in PAGES:
            f = BASE_DIR / PAGES[path]
            return ("file", f, PAGE_TYPES.get(f.suffix)) if f.is_file() else (None,)
        if path.startswith("/assets/"):
            f = (BASE_DIR / path.lstrip("/")).resolve()
            root = (BASE_DIR / "assets").resolve()
            ctype = ASSET_TYPES.get(f.suffix.lower())
            if ctype and root in f.parents and f.is_file():
                return "file", f, ctype
        return (None,)

    def serve_static(self, path, head=False):
        res = self.resolve_static(path)
        if res[0] == "redirect":
            return self.send_bytes(301, b"", "text/plain", {"Location": res[1]}, head=True)
        if res[0] != "file":
            return self.send_bytes(404, b"Not found", "text/plain; charset=utf-8", {"Cache-Control": "no-store"}, head)
        _, f, ctype = res
        st = f.stat()
        key = (str(f), st.st_mtime_ns, st.st_size)
        hit = _static_cache.get(str(f))
        if not hit or hit[0] != key:
            data = f.read_bytes()
            hit = (key, data, '"%s"' % hashlib.sha1(data).hexdigest()[:20])
            _static_cache[str(f)] = hit
        _, data, etag = hit
        if f.suffix.lower() in (".woff", ".woff2"):
            cache = "public, max-age=31536000, immutable"
        elif f.suffix.lower() in (".css", ".js", ".html", ".txt"):
            cache = "no-cache"            # always revalidate; the ETag makes that a cheap 304
        else:
            cache = "public, max-age=86400"
        headers = {"ETag": etag, "Cache-Control": cache}
        if self.headers.get("If-None-Match") == etag:
            return self.send_bytes(304, b"", ctype, headers, head=True)
        self.send_bytes(200, data, ctype, headers, head)

    # -- public API ---------------------------------------------------------
    def api_status(self):
        with STORE.lock:
            self.send_json({"ok": True, "open": bool(STORE.data["admissions_open"])})

    def _rate_limited(self):
        if LIMITER.check_and_add("submit:" + self.client_ip(), SUBMIT_WINDOW, SUBMIT_MAX):
            self.error_json(429, "Too many submissions. Please try again later.")
            return True
        return False

    def api_apply(self):
        if self._rate_limited():
            return
        data = self.read_json()
        if data is None:
            return
        if clean(data.get("website"), 100):          # honeypot: bots fill hidden fields
            return self.send_json({"ok": True, "reference": "RAHMA-%d-0000" % date.today().year})

        child = clean(data.get("child_name"), 100)
        dob_raw = clean(data.get("dob"), 10)
        gender = clean(data.get("gender"), 10)
        programme = clean(data.get("programme"), 20)
        parent = clean(data.get("parent_name"), 100)
        phone = clean(data.get("phone"), 20)
        notes = clean(data.get("notes"), 1000)

        errors = {}
        if len(child) < 2:
            errors["child_name"] = "Please enter the child's full name."
        dob = parse_dob(dob_raw)
        if not dob:
            errors["dob"] = "Please enter a valid date of birth."
        else:
            age = (date.today() - dob).days / 365.25
            if dob > date.today() or age < 3 or age > 25:
                errors["dob"] = "Date of birth must give an age between 3 and 25 years."
        if gender not in GENDERS:
            errors["gender"] = "Please select a gender."
        if programme not in PROGRAMMES:
            errors["programme"] = "Please select a programme."
        if len(parent) < 2:
            errors["parent_name"] = "Please enter the parent or guardian's name."
        if not valid_phone(phone):
            errors["phone"] = "Please enter a valid phone number."
        if errors:
            return self.send_json({"ok": False, "error": "Please correct the highlighted fields.", "fields": errors}, 422)

        with STORE.lock:
            d = STORE.data
            if not d["admissions_open"]:
                return self.error_json(403, "Admissions are currently closed.", closed=True)
            # A double-click or retry returns the existing reference instead of a duplicate record.
            sig = (child.lower(), dob_raw, re.sub(r"\D", "", phone), programme)
            for a in d["applications"]:
                if (a["child_name"].lower(), a["dob"], re.sub(r"\D", "", a["phone"]), a["programme"]) == sig:
                    return self.send_json({"ok": True, "reference": a["reference"], "duplicate": True})
            existing = {a["reference"] for a in d["applications"]}
            alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
            while True:
                ref = "RAHMA-%d-%s" % (date.today().year, "".join(secrets.choice(alphabet) for _ in range(4)))
                if ref not in existing:
                    break
            d["applications"].append({
                "reference": ref, "child_name": child, "dob": dob_raw, "gender": gender,
                "programme": programme, "programme_label": PROGRAMMES[programme],
                "parent_name": parent, "phone": phone, "notes": notes, "submitted_at": now_iso(),
            })
            STORE.save()
        log("application %s received" % ref)
        self.send_json({"ok": True, "reference": ref}, 201)

    def api_contact(self):
        if self._rate_limited():
            return
        data = self.read_json()
        if data is None:
            return
        if clean(data.get("website"), 100):          # honeypot
            return self.send_json({"ok": True})

        name = clean(data.get("name"), 100)
        email = clean(data.get("email"), 254)
        phone = clean(data.get("phone"), 20)
        message = clean(data.get("message"), 2000)

        errors = {}
        if len(name) < 2:
            errors["name"] = "Please enter your name."
        if not email and not phone:
            errors["email"] = "Provide an email address or a phone number."
        if email and not valid_email(email):
            errors["email"] = "Please enter a valid email address."
        if phone and not valid_phone(phone):
            errors["phone"] = "Please enter a valid phone number."
        if len(message) < 5:
            errors["message"] = "Please write a short message."
        if errors:
            return self.send_json({"ok": False, "error": "Please correct the highlighted fields.", "fields": errors}, 422)

        with STORE.lock:
            STORE.data["messages"].append({
                "id": secrets.token_hex(4), "name": name, "email": email, "phone": phone,
                "message": message, "received_at": now_iso(),
            })
            STORE.save()
        self.send_json({"ok": True}, 201)

    # -- admin API ----------------------------------------------------------
    def api_login(self):
        ip = self.client_ip()
        ip_key, global_key = "login:" + ip, "login:*"
        if LIMITER.count(ip_key, LOGIN_WINDOW) >= LOGIN_MAX_FAILS_PER_IP or \
                LIMITER.count(global_key, LOGIN_WINDOW) >= LOGIN_MAX_FAILS_GLOBAL:
            return self.error_json(429, "Too many failed attempts. Try again in a few minutes.")
        data = self.read_json()
        if data is None:
            return
        user = data.get("username") if isinstance(data.get("username"), str) else ""
        pwd = data.get("password") if isinstance(data.get("password"), str) else ""
        pwd = pwd[:256]
        # Always run the hash so response time does not reveal whether the username was right.
        user_ok = hmac.compare_digest(user.encode(), ADMIN_USER.encode())
        pass_ok = verify_password(pwd, ADMIN_HASH if user_ok else DUMMY_HASH)
        if not (user_ok and pass_ok):
            LIMITER.add(ip_key, LOGIN_WINDOW)
            LIMITER.add(global_key, LOGIN_WINDOW)
            log("failed admin login from %s" % ip)
            return self.error_json(401, "Invalid username or password.")
        LIMITER.clear(ip_key)
        log("admin login from %s" % ip)
        self.send_json({"ok": True, "token": SESSIONS.create(), "expires_in": SESSION_TTL})

    def api_logout(self):
        SESSIONS.revoke(self.bearer())
        self.send_json({"ok": True})

    def api_toggle(self):
        if not self.require_admin():
            return
        body = {}
        if self.headers.get("Content-Length") not in (None, "", "0"):
            body = self.read_json()
            if body is None:
                return
        with STORE.lock:
            d = STORE.data
            d["admissions_open"] = body["open"] if isinstance(body.get("open"), bool) else not d["admissions_open"]
            STORE.save()
            state = d["admissions_open"]
        log("admissions set to %s by admin (%s)" % ("OPEN" if state else "CLOSED", self.client_ip()))
        self.send_json({"ok": True, "open": state})

    def api_admin_applications(self):
        if not self.require_admin():
            return
        with STORE.lock:
            d = STORE.data
            payload = {
                "ok": True, "open": d["admissions_open"],
                "applications": list(reversed(d["applications"])),
                "messages": list(reversed(d["messages"])),
            }
        self.send_json(payload)


# --------------------------------------------------------------------------
# Start-up
# --------------------------------------------------------------------------
def preflight():
    problems = []
    user, stored, cred_problems = load_credentials()
    problems += cred_problems
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        probe = DATA_DIR / ".write-test"
        probe.write_text("ok")
        probe.unlink()
    except OSError as exc:
        problems.append("Data directory %s is not writable: %s" % (DATA_DIR, exc))
    for page in ("index.html", "admin.html"):
        if not (BASE_DIR / page).is_file():
            problems.append("Missing %s" % page)
    if not (BASE_DIR / "assets" / "css" / "app.css").is_file():
        problems.append("Missing assets/css/app.css")
    if PRODUCTION and HOST not in ("127.0.0.1", "::1", "localhost") and not os.environ.get("RAHMA_ALLOW_PUBLIC_BIND"):
        problems.append("HOST=%s exposes the app without HTTPS. Bind to 127.0.0.1 behind a reverse proxy "
                        "(or set RAHMA_ALLOW_PUBLIC_BIND=1 if a firewall/proxy handles this)." % HOST)
    return user, stored, problems


def main():
    global STORE, SESSIONS, ADMIN_USER, ADMIN_HASH
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--check", action="store_true", help="validate configuration and exit")
    parser.add_argument("--hash-password", action="store_true", help="print a password hash and exit")
    args = parser.parse_args()

    if args.hash_password:
        pw = getpass.getpass("New admin password: ")
        if getpass.getpass("Repeat password: ") != pw:
            sys.exit("Passwords do not match.")
        if len(pw) < MIN_PASSWORD_LEN or pw.lower() in BANNED_PASSWORDS:
            sys.exit("Use at least %d characters and avoid common passwords." % MIN_PASSWORD_LEN)
        print(hash_password(pw))
        return

    ADMIN_USER, ADMIN_HASH, problems = preflight()
    if problems:
        print("Configuration problems:", file=sys.stderr)
        for p in problems:
            print("  - " + p, file=sys.stderr)
        sys.exit(1)
    if args.check:
        print("Configuration OK (%s mode)." % ("production" if PRODUCTION else "development"))
        return

    STORE = Store(DATA_DIR)
    SESSIONS = Sessions(DATA_DIR)

    ThreadingHTTPServer.request_queue_size = 128
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    stop = lambda *_: threading.Thread(target=httpd.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    log("Rahma server listening on http://%s:%d (%s mode, data in %s)"
        % (HOST, PORT, "production" if PRODUCTION else "DEVELOPMENT", DATA_DIR))
    if not PRODUCTION:
        log("DEVELOPMENT mode: default admin credentials are enabled. Never use this on a public server.")
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
        log("Server stopped.")


if __name__ == "__main__":
    main()
