# Deploying Rahma Islamic School website

## Install (Ubuntu/Debian server)

1. Point your domain's DNS A record at the server and open ports 80 and 443.
2. Copy this folder to the server and run:

   ```
   sudo ./deploy/install.sh school.example.com you@example.com
   ```

The installer sets up the app as a service that restarts automatically, nginx with HTTPS (free Let's Encrypt certificate, renewed automatically), rate limiting, and a strong generated admin password, which it prints once. Re-running the same command deploys updates and keeps your data, password and certificate.

## Everyday tasks

| Task | Command |
|---|---|
| Change the admin password | `python3 /opt/rahma/server.py --hash-password`, paste the result into `RAHMA_ADMIN_PASS_HASH` in `/etc/rahma/rahma.env`, then `sudo systemctl restart rahma` |
| View logs | `sudo journalctl -u rahma -f` |
| Restart | `sudo systemctl restart rahma` |
| Where the data is | `/var/lib/rahma/store.json` (daily backups in `/var/lib/rahma/backups`, last 30 kept) |
| Change gallery photos | put images in `assets/gallery/`, edit the gallery list in `assets/js/site.js`, re-run the installer |
| Edit page text or styling | edit `index.html`, then rebuild CSS if you added new Tailwind classes (`tools/build-css.js`) and re-run the installer |

## Running locally for development

```
RAHMA_ENV=development python3 server.py
```

Development mode accepts the default login (`admin` / `rahma2026dodowa`) and is for your own computer only. Production mode refuses to start with a weak or missing password.
